import os

a = 'Prakash\n'           #Normally use single quotes for Strings
b = "Prakash's\n"         #Use double Quotes if you want to use single quote inside string 
c = 'Prakash"s\n'         #Use Single Quote if you want to use Double quotes inside string
d = '''Prak
            a's"h\n'''     #Use Triple quotes if you want to use both Single Quote and Double quotes inside a string 
#(Also Double quotes inside Triple Quote Prints an extra "\" in String" if Livecode extension is used in VScode)

print(a, b, c, d)       

