
#Solution of Practice Set Q4

import os

string = "abra  kaDabra"

NewString = string.replace("  ", " ") 
#if there are more then double space then it will not be effective

print(NewString)


