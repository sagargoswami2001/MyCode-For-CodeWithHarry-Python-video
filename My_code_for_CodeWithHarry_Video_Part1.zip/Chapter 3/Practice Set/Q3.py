#Solution of Practice Set Q3

import os

string = "abra  kaDabra"

doubleSpaceLocation = string.find("  ")

print(doubleSpaceLocation)


