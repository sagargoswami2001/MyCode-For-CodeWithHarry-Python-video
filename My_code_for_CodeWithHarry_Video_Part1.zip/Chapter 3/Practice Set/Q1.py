#Solution of Practice Set Q1

import os

a = input("Enter a Name: ")

print("Good Morning, " + a)


