#Solution of Practice Set Q5

import os 
print("Black and Blue i crawl along,\n\tDid we Wreck it down what now is gone?\n\n")

#Method 2

letter = "Black and Blue i crawl along, Did we Wreck it down what now is gone?"

newletter = "Black and Blue i crawl along,\n\tDid we Wreck it down what now is gone?"

print(newletter)



