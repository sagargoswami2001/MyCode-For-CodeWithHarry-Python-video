import os 

print("This is a Random\nString to\tshow\'working of\\ Escape Sequences!")

