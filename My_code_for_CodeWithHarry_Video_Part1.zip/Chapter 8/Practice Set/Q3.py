# #Practice set Q3
#Author: Prakash

import os 

print("Line 1", end=" ")
print("Still Line 1", end=".")
