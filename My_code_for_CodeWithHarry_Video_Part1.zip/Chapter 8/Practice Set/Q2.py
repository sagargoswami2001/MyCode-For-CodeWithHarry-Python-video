#Practice set Q2
#Author: Prakash

import os 

#Fixed typo in fahrenheit in video 
def fahr(cel):
    return  (cel*9/5)+32  


c = 37
f = fahr(c)

print("fahrenheit Temperature is: " + str(f))


