#Author: Parakash
#FUNCTION WITH ARGUMENTS (already covered in Q1)
#Here an example of a function with two arguments

no1 = 2
no2 = 3

def sum2(no1, no2):
    return(no1+no2)

print("Sum of 2 numbers: ", sum2(no1, no2))