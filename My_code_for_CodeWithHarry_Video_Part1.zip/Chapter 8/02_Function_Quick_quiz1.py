# Function_Quick_quiz1 in Python, greet user using function
#Author: Prakash

import os 

def greeting(name):
    print(f"Good Morning, {name}")


name = input("Enter a name: ")
greeting(name)
