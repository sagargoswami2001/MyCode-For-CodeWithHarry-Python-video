# A Prorgram to show example 2 in Python
#Author: Prakash

import os 

print("Welcome!")

for i in range(0, 7):
    print(i)
