# A Prorgram to show for loop with else clause in Python
#Author: Prakash

import os 

print("Welcome!")

for i in range(10): #This loop keeps iterating till condition become false and one condition is false else clause is executed
    print(i)
else: # This is Optionl part
    print('-1')
    
# Note: else can also be used with while loops in same manner

