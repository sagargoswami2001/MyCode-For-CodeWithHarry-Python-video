# A Prorgram to print 1 to 50 using a while loop
#Author: Prakash
import os 

n = 1
while(n <= 50): #n starts from 1 and checked till 51 where condition become false
                #if condition is kept as (n<50) then it will print fron 1-49 because 49<50 but 50!<50(50 is not less than 50)
    print(n)
    n+=1
