# A Prorgram to show an example in Python
#Author: Prakash

import os 

i=0

while (i<5):
    print("Prakash")
    i+=1
