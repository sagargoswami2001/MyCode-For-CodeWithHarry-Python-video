# A Prorgram to print contents of a list using while loop in Python
#Author: Prakash

import os 

i=0
aList = [1,2,4,6,3,5,8]

while (i<len(aList)):#Finding the length of aList which is 6 and iterating loop till < 7 because intex starts from 0    print(aList[i])
    i+=1
    
print(len(aList)) # Length is 7





