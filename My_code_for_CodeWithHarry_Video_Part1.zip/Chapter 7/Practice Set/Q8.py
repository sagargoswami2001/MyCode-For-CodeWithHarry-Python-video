#Practice set Q8
#Author: Prakash

import os 

for i in range(4):
    print("*" * (i+1))
