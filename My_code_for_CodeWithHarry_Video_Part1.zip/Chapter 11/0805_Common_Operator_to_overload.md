![](image/0805_Common_Operator_to_overload/1647794715337.png)
