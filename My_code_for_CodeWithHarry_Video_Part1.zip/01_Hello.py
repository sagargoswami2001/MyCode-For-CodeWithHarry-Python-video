txt = "Hello"
x = txt[2:5]
print(x)




