#Solution of Practice Set Q2

'''in python REPL'''
# Open REPL using py command on CMD or powershell

'''Execute these Commands One by One'''
5*1

5*2

5*3

5*4

5*5

5*6

5*7

5*8

5*9

5*10
