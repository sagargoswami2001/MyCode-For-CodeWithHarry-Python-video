#Solution of Practice Set Q4
# Date: Nov 23, 2021
# Author: Prakash

import os

#Printing contents of Custom Directory 
li = os.listdir("D:\\Users\\Zaphkil!\\Documents\\VS Code\\Python")
print(li)

#Printing constents of Working Directory
print(os.listdir())
