# Author: Prakash
import os
print("Hello, World!")

