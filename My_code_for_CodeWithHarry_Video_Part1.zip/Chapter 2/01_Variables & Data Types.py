import os

# Variable that store a int that is determined by the data itself
a = 55

# Variable that store a float that is determined by the data itself
b = 44.95

# Variable that store a string that is determined by the data itself
# Method 1
c = 'Tekken 3'

# Variable that store a string that is determined by the data itself
# Method 2 
# in this method you can use Single quotes between String
e = "Tekken'3"

# Variable that store a string that is determined by the data itself
# Method 2 
# in this method you can use Single and double quotes between String as well as Span to multiple Lines
f = '''Tek'ken" 3'''

# Variable that store a bool that is determined by the data itself
g = True
h = False

# variable that store none
i = None

#Printing the variables
print(a)
print(b)
print(c)
print(e)
print(f)
print(g)
print(h)
print(i)

print('\n') #printing new line

#Printing the DataType of variables
print(type(a))
print(type(b))
print(type(c))
print(type(e))
print(type(f))
print(type(g))
print(type(h))
print(type(i))
