#Solution of Practice Set Q5

import os

a = input("Enter 1st no:")#Takes the input from user as a "String" to use that value as int of float 
                                    # You will have to Typecast it to int or float
a = int(a)                 # Typecasting String a into int a because string is a no and can be converted to int 

b = input("Enter 2nd no:")#Takes the input from user as a "String" to use that value as int of float 
                                    # You will have to Typecast it to int or float
b = int(b)                 # Typecasting String a into int a because string is a no and can be converted to int 

print("Avarage of Two no:", (a+b)/2) #Finding Avarage
