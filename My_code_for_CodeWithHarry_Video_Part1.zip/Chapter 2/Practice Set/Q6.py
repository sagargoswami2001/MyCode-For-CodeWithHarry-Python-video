#Solution of Practice Set Q6

import os

a = input("Enter 1st no:") #Takes the input from user as a "String" to use that value as int of float 
                                    # You will have to Typecast it to int or float
a = int(a)                 # Typecasting String a into int a because string is a no and can be converted to int 

print("Square of no:", a*a) #Finding Square of the input no. 
