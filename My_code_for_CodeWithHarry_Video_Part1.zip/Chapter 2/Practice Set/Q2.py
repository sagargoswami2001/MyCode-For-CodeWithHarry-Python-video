#Solution of Practice Set Q2

import os 

a = 55

print(a%2)  #finding The Remainder When a No is Devided by 2

