#Solution of Practice Set Q3

import os 

a = input("Enter The Value of a:")
print(type(a))
