#Solution of Practice Set Q4

import os

a = 34
b = 80

c = (a>b) # Is a Greater than b?

print(c)


c = (b>a) # Is b Greater than a?

print(c)

