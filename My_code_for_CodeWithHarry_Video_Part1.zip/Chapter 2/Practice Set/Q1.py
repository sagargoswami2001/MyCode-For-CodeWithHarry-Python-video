#Solution of Practice Set Q1

import os 

a = 55 
b = 97

print("Sum of a and b is: ", a+b)

