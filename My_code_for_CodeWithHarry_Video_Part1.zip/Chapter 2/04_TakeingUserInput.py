import os

a = input("Enter the Value of a: ") #Takes the input from user as a "String" to use that value as int of float 
                                    # You will have to Typecast it to int or float
print (type(a)) # Currently it have type string 
print (a)

a = int(a)  # Typecasting String a into int a because string is a no and can be converted to int 
print (type(a)) # Currently it have type int
print(a+54)


