import os 

age = int(input("Enter Your age: "))

if(age>18):
    print("you are an adult")
else:
    print("you are not an adult")
