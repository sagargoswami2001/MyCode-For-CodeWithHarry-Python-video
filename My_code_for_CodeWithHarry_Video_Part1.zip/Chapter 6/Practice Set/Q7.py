#Solution of Practice Set Q6

import os 

Post = input("Post:")

if("Prakash" in Post or "PRAKASH" in Post or "prakash" in Post):
    print("Post is talking about me ")
else:
    print("Post isn't talking about me ")