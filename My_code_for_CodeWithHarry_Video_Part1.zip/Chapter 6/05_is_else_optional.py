a = 6
if(a==7):
    print("yes")
elif(a>56):
    print("no and yes")
else:
    print("I am optional") #else statement is optional in both if-else and if-elif-else clauses
    
    
if(a==7):
    print("yes")
elif(a>56):
    print("no and yes")