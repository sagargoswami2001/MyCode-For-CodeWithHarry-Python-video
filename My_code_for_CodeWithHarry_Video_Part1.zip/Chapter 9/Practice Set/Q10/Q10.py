#Practice set Q10
#Author: Prakash
import os

with open("Chapter 9//Practice Set//Q10//crap.txt","w")as f:
    f.write("")