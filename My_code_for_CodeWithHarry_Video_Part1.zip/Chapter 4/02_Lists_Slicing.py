import os
a = [45, 945, 77.69, 9, False, 7, 'apple']

#Slicing can also be done in Lists
print(a[0:7]) #slicing string
print(a[0:7:2]) #slicing with skipping
print(a[-5:])
