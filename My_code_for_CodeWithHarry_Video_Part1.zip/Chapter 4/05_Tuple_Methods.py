import os

t = (0,8,6,9,4,'A',8)

print(t.count(8))   #Returns the no of times 8 is found in tuple
print(t.index(9))   #Returns the index of first occurance  of 9 in tuple
