#Solution of Practice Set Q3

import os 

t = (0,8,6,9,4,'A')

t[0]=5 
#IT will Throw an Error as tuple can't be updated
