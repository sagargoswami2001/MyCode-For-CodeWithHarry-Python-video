#Solution of Practice Set Q5

import os 

a = (7,0,8,0,0,9)

print(a.count(0))
