#Solution of Practice Set Q1

import os 

f1 = input("Enter Name Of Fruit 1:" )
f2 = input("Enter Name Of Fruit 2:" )
f3 = input("Enter Name Of Fruit 3:" )
f4 = input("Enter Name Of Fruit 4:" )
f5 = input("Enter Name Of Fruit 5:" )
f6 = input("Enter Name Of Fruit 6:" )
f7 = input("Enter Name Of Fruit 7:" )

myFruits = [f1,f2,f3,f4,f5,f6,f7]

print(myFruits)
