#Solution of Practice Set Q4

import os 

a = [4,5,9,6]

print(a[0]+a[1]+a[2]+a[3]) #Hardcoding list sum

print(sum(a)) #using List method sum
