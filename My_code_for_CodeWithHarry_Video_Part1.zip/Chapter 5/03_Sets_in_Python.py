import os

a = {1,2,3,4,5,5,4,3,2,1} #Set diclaration quite similar to Dict
                            #Set can't Have Repeated values

print(a)                    #prints repeated elements only once
print(type(a))              #prints Type of a which is set

