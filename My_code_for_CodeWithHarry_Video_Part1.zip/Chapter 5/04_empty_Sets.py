import os

#a = {1,2,3,4,5,5,4,3,2,1}
a={} # This will Create a empty dictionary and not a Empty Set 

print(type(a)) #prints Type as Dictionary

#For an Empty Set This syntax is used
b = set() 
print(type(b))

