#Solution of Practice Set Q9    

import os

# S = {8,7,12,"Dang", [1,2]} 
# Set can't store list
# #will Throw an Error as Lists are unhashable
