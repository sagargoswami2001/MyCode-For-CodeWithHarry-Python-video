#Solution of Practice Set Q8   

import os

FavLanguage = {}

a = input("Enter Your language Akash:") #assume input C++
b = input("Enter Your language Sagar:")
c = input("Enter Your language Kirti:")
d = input("Enter Your language Harsh:") # Assume input C++  #Values don't need to be unique,Two key Can have same Values 

FavLanguage["Akash"]=a # assigning inputs to specific keys
FavLanguage["Sagar"]=b
FavLanguage["Kirti"]=c
FavLanguage["Harsh"]=d 

print(FavLanguage)
