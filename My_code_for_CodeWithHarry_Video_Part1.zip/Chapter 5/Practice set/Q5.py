#Solution of Practice Set Q5

s = {}

print(type(s)) #Type Dictionary is Printed