#Solution of Practice Set Q6    

import os

FavLanguage = {}

a = input("Enter Your language Akash:")
b = input("Enter Your language Sagar:")
c = input("Enter Your language Kirti:")
d = input("Enter Your language Harender:")

FavLanguage["Akash"]=a # assigning inputs to specific keys
FavLanguage["Sagar"]=b
FavLanguage["Kirti"]=c
FavLanguage["Harender"]=d

print(FavLanguage)
