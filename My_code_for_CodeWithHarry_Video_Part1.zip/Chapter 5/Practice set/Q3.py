#Solution of Practice Set Q3

import os

S = set()
S.add(18) #Set can have data of multiple data type 18 is int and "18" is string they are considred different element
S.add("18")
S.add(512)

print(S)


